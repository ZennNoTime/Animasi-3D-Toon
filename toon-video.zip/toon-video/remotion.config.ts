import {Config} from '@remotion/cli/config';
Config.setVideoImage('jpeg');
Config.setOverwriteOutput(true);
Config.setChromiumOpenGlRenderer('angle');
