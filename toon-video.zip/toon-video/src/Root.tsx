import React from 'react';
import {Composition, staticFile} from 'remotion';
import {getAudioDurationInSeconds} from '@remotion/media-utils';
import {Scene} from './Scene';

const FPS = 30;
const AUDIO = staticFile('voice.mp3');

// Durasi video otomatis = durasi audio (±84.77 dtk)
const calculateMetadata = async () => {
  const seconds = await getAudioDurationInSeconds(AUDIO);
  return {durationInFrames: Math.ceil(seconds * FPS)};
};

export const RemotionRoot: React.FC = () => (
  <>
    <Composition
      id="Toon3D"
      component={Scene}
      durationInFrames={2544}
      fps={FPS}
      width={1920}
      height={1080}
      calculateMetadata={calculateMetadata}
    />
    <Composition
      id="Toon3D-Vertical"
      component={Scene}
      durationInFrames={2544}
      fps={FPS}
      width={1080}
      height={1920}
      calculateMetadata={calculateMetadata}
    />
  </>
);
