import React, {useMemo} from 'react';
import {AbsoluteFill, Audio, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {useAudioData, visualizeAudio} from '@remotion/media-utils';
import {ThreeCanvas} from '@remotion/three';
import * as THREE from 'three';

const AUDIO = staticFile('voice.mp3');
const INK = '#14101f';

// ---------- Toon helpers ----------
const useGradient = () =>
  useMemo(() => {
    const data = new Uint8Array([70, 150, 255]); // 3 pita cel-shading
    const tex = new THREE.DataTexture(data, data.length, 1, THREE.RedFormat);
    tex.minFilter = tex.magFilter = THREE.NearestFilter;
    tex.generateMipmaps = false;
    tex.needsUpdate = true;
    return tex;
  }, []);

type ToonProps = {
  color: string;
  geometry: React.ReactElement;
  outline?: number;
  gradient: THREE.Texture;
} & JSX.IntrinsicElements['group'];

// Mesh toon + outline (inverted hull) ala kartun
const Toon: React.FC<ToonProps> = ({color, geometry, outline = 0.07, gradient, children, ...rest}) => (
  <group {...rest}>
    <mesh>
      {geometry}
      <meshToonMaterial color={color} gradientMap={gradient} />
    </mesh>
    {outline > 0 && (
      <mesh scale={1 + outline}>
        {geometry}
        <meshBasicMaterial color={INK} side={THREE.BackSide} />
      </mesh>
    )}
    {children}
  </group>
);

const sphere = <sphereGeometry args={[1, 40, 40]} />;
const box = <boxGeometry args={[1, 1, 1]} />;
const capsule = <capsuleGeometry args={[0.5, 1, 12, 24]} />;

// ---------- Karakter ----------
const Character: React.FC<{energy: number; frame: number; fps: number; g: THREE.Texture}> = ({energy, frame, fps, g}) => {
  const t = frame / fps;
  const intro = spring({frame, fps, config: {damping: 9, stiffness: 90}});
  const open = Math.min(1, energy * 1.6);
  const blink = frame % 96 > 91 ? 0.1 : 1;
  const bob = Math.sin(t * 2.2) * 0.06 + energy * 0.12;
  const talkTilt = Math.sin(t * 3.1) * 0.06 * (0.3 + energy);
  const armSwing = Math.sin(t * 4) * 0.25 * energy;

  return (
    <group scale={Math.max(0.001, intro)} position={[0, -0.2 + bob, 0]} rotation={[0, Math.sin(t * 0.7) * 0.2, talkTilt]}>
      {/* badan */}
      <Toon gradient={g} color="#2d3a8c" geometry={capsule} position={[0, -2.1, 0]} scale={[1.9, 1.5, 1.2]} />
      {/* kemeja + dasi */}
      <Toon gradient={g} color="#f5f2ff" geometry={box} position={[0, -1.55, 0.62]} scale={[0.7, 0.9, 0.12]} outline={0.1} />
      <Toon gradient={g} color="#e63946" geometry={box} position={[0, -1.7, 0.72]} scale={[0.22, 0.8, 0.1]} outline={0.15} />
      {/* lengan */}
      <Toon gradient={g} color="#2d3a8c" geometry={capsule} position={[-1.35, -1.9, 0.1]} rotation={[0, 0, 0.35 + armSwing]} scale={[0.6, 1.1, 0.6]} />
      <Toon gradient={g} color="#2d3a8c" geometry={capsule} position={[1.35, -1.9, 0.1]} rotation={[0, 0, -0.35 - armSwing]} scale={[0.6, 1.1, 0.6]} />
      {/* leher */}
      <Toon gradient={g} color="#f1b48a" geometry={sphere} position={[0, -0.75, 0]} scale={[0.45, 0.4, 0.45]} />
      {/* kepala */}
      <Toon gradient={g} color="#ffc9a0" geometry={sphere} position={[0, 0.7, 0]} scale={[1.3, 1.3, 1.2]}>
        {/* rambut */}
        <Toon gradient={g} color="#1c1c2b" geometry={sphere} position={[0, 0.55, -0.15]} scale={[1.02, 0.6, 1.0]} />
      </Toon>
      {/* telinga */}
      <Toon gradient={g} color="#f1b48a" geometry={sphere} position={[-1.7, 0.6, 0]} scale={0.25} />
      <Toon gradient={g} color="#f1b48a" geometry={sphere} position={[1.7, 0.6, 0]} scale={0.25} />
      {/* alis tegas */}
      <Toon gradient={g} color={INK} geometry={box} position={[-0.55, 1.18 - open * 0.04, 1.25]} rotation={[0, 0, -0.28]} scale={[0.6, 0.13, 0.12]} outline={0} />
      <Toon gradient={g} color={INK} geometry={box} position={[0.55, 1.18 - open * 0.04, 1.25]} rotation={[0, 0, 0.28]} scale={[0.6, 0.13, 0.12]} outline={0} />
      {/* mata */}
      {[-0.55, 0.55].map((x) => (
        <group key={x} position={[x, 0.78, 1.18]} scale={[1, blink, 1]}>
          <Toon gradient={g} color="#ffffff" geometry={sphere} scale={[0.3, 0.34, 0.2]} outline={0.1} />
          <mesh position={[0, 0, 0.17]} scale={[0.14, 0.17, 0.08]}>
            {sphere}
            <meshBasicMaterial color={INK} />
          </mesh>
        </group>
      ))}
      {/* hidung */}
      <Toon gradient={g} color="#f1a57a" geometry={sphere} position={[0, 0.5, 1.3]} scale={[0.14, 0.18, 0.14]} />
      {/* mulut mengikuti suara */}
      <group position={[0, 0.05, 1.22]}>
        <mesh scale={[0.38 + open * 0.08, 0.05 + open * 0.3, 0.12]}>
          {sphere}
          <meshBasicMaterial color="#3b0a1a" />
        </mesh>
        <mesh position={[0, 0.08 + open * 0.1, 0.08]} scale={[0.3, 0.05, 0.03]}>
          {sphere}
          <meshBasicMaterial color="#ffffff" />
        </mesh>
      </group>
    </group>
  );
};

// ---------- Latar ----------
const Backdrop: React.FC<{spectrum: number[]; frame: number; fps: number; g: THREE.Texture}> = ({spectrum, frame, fps, g}) => {
  const t = frame / fps;
  const palette = ['#ff4d6d', '#ffb703', '#4cc9f0', '#80ed99', '#b5179e'];
  const bars = spectrum.length;
  return (
    <>
      {/* lantai */}
      <Toon gradient={g} color="#3a2d7a" geometry={<cylinderGeometry args={[6, 6, 0.4, 64]} />} position={[0, -3.9, -1]} />
      {/* bar spektrum melingkar */}
      {spectrum.map((v, i) => {
        const a = (i / bars) * Math.PI * 2;
        const h = 0.3 + Math.min(1, v * 6) * 3.2;
        return (
          <Toon
            key={i}
            gradient={g}
            color={palette[i % palette.length]}
            geometry={box}
            position={[Math.cos(a) * 5.2, -3.6 + h / 2, Math.sin(a) * 3 - 3.5]}
            scale={[0.5, h, 0.5]}
            outline={0.12}
          />
        );
      })}
      {/* bentuk melayang */}
      {Array.from({length: 9}).map((_, i) => {
        const a = i * 1.9;
        const x = Math.sin(a) * 6 + Math.sin(t * 0.5 + i) * 0.4;
        const y = Math.cos(a * 1.3) * 3 + Math.sin(t * 0.9 + i * 2) * 0.5;
        const geo =
          i % 3 === 0 ? <icosahedronGeometry args={[0.5, 0]} /> : i % 3 === 1 ? <torusGeometry args={[0.4, 0.15, 16, 32]} /> : <octahedronGeometry args={[0.5]} />;
        return (
          <Toon
            key={i}
            gradient={g}
            color={palette[(i + 2) % palette.length]}
            geometry={geo}
            position={[x, y, -5 - (i % 3)]}
            rotation={[t * 0.8 + i, t * 0.6, 0]}
            scale={1 + (i % 3) * 0.3}
          />
        );
      })}
    </>
  );
};

// ---------- Komposisi ----------
export const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, width, height, durationInFrames} = useVideoConfig();
  const audioData = useAudioData(AUDIO);
  const g = useGradient();

  let spectrum: number[] = new Array(32).fill(0);
  let energy = 0;
  if (audioData) {
    // rata-rata beberapa frame supaya gerakan mulut halus
    const samples = [0, 1, 2].map((d) =>
      visualizeAudio({fps, frame: Math.max(0, frame - d), audioData, numberOfSamples: 32, smoothing: false}),
    );
    spectrum = samples[0];
    const voiceBins = (s: number[]) => s.slice(1, 12).reduce((a, b) => a + b, 0) / 11;
    energy = Math.min(1, (samples.reduce((a, s) => a + voiceBins(s), 0) / samples.length) * 5);
  }

  const portrait = height > width;
  const hue = interpolate(frame, [0, durationInFrames], [250, 330]);
  const fadeOut = interpolate(frame, [durationInFrames - 20, durationInFrames], [0, 1], {extrapolateLeft: 'clamp'});

  return (
    <AbsoluteFill style={{background: `linear-gradient(160deg, hsl(${hue},70%,55%), hsl(${hue + 50},80%,35%))`}}>
      <Audio src={AUDIO} />
      <ThreeCanvas width={width} height={height} camera={{position: [0, 0.3, portrait ? 11 : 8], fov: 42}} style={{background: 'transparent'}}>
        <ambientLight intensity={0.9} />
        <directionalLight position={[4, 6, 6]} intensity={2.2} />
        <Backdrop spectrum={spectrum} frame={frame} fps={fps} g={g} />
        <Character energy={energy} frame={frame} fps={fps} g={g} />
      </ThreeCanvas>
      <AbsoluteFill style={{background: '#000', opacity: fadeOut, pointerEvents: 'none'}} />
    </AbsoluteFill>
  );
};
