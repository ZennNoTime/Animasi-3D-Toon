# Toon 3D Video (Remotion)

1. `npm install`
2. `npm run dev`             -> preview di Remotion Studio
3. `npm run render`          -> out/toon.mp4 (1920x1080)
   `npm run render:vertical` -> out/toon-vertical.mp4 (1080x1920)

Durasi otomatis mengikuti audio (public/voice.mp3, 84.77 dtk = 2544 frame @30fps).
